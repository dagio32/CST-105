public interface Celebrator
{
	// celebrate() method will print a message to the console
	// To be implemented in the NFLPlayer, OffensivePlayer, and DefensivePlayer classes
	void celebrate();
}